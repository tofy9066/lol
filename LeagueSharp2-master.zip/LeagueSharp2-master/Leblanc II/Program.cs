using LeagueSharp;

namespace Leblanc
{
    internal class Program
    {
        
        private static void Main(string[] args)
        {
            Leblanc.Init();
        }
    }
}